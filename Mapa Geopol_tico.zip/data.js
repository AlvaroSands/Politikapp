/* =========================================================
   Dataset demo — eventos geopolíticos (boceto v0.1)
   Datos ilustrativos para validar el diseño visual.
   ========================================================= */

window.GEO_EVENTS = [
  {
    id: "EV-001",
    type: "armed",
    severity: 5,
    title: "Frente activo en Europa Oriental",
    location: "Donbás · Ucrania oriental",
    coords: [37.5, 48.5],
    started: "2022-02-24",
    updated: "2026-05-08T14:22Z",
    actors: ["UA", "RU", "OTAN", "UE"],
    casualties: "alta",
    summary:
      "Operaciones convencionales sostenidas a lo largo de un frente de ~1.000 km. Intercambios de artillería y drones reportados en las últimas 24h. Corredor humanitario parcialmente operativo.",
    timeline: [
      { when: "T-2h",  what: "Reportes de ataques con drones en sector norte." },
      { when: "T-9h",  what: "Convoy logístico identificado vía SIGINT." },
      { when: "T-24h", what: "Cumbre de aliados anuncia paquete adicional." }
    ]
  },
  {
    id: "EV-002",
    type: "armed",
    severity: 5,
    title: "Operaciones urbanas en zona costera",
    location: "Levante mediterráneo",
    coords: [34.5, 31.5],
    started: "2023-10-07",
    updated: "2026-05-09T06:11Z",
    actors: ["IL", "PS", "EG", "ONU"],
    casualties: "alta",
    summary:
      "Combate urbano sostenido y desplazamientos forzados. Mediación regional intermitente. Acceso humanitario restringido a tres corredores.",
    timeline: [
      { when: "T-6h",  what: "Convoy de ayuda accede por paso sur." },
      { when: "T-18h", what: "Reanudación de hostilidades tras tregua táctica." }
    ]
  },
  {
    id: "EV-003",
    type: "armed",
    severity: 4,
    title: "Conflicto interno en Cuerno de África",
    location: "Sudán central",
    coords: [30.0, 15.5],
    started: "2023-04-15",
    updated: "2026-05-07T22:00Z",
    actors: ["FAS", "RSF", "UA", "ONU"],
    casualties: "alta",
    summary:
      "Disputa entre fuerzas regulares y paramilitares. Crisis de desplazamiento interno con impacto regional en países vecinos.",
    timeline: [
      { when: "T-12h", what: "Combates en periferia de la capital." },
      { when: "T-2d",  what: "Nuevo flujo de refugiados hacia Chad." }
    ]
  },
  {
    id: "EV-004",
    type: "armed",
    severity: 4,
    title: "Insurgencia en franja del Sahel",
    location: "Triple frontera · Sahel central",
    coords: [-1.5, 14.0],
    started: "2012-01-01",
    updated: "2026-05-08T11:40Z",
    actors: ["Estados del Sahel", "Grupos armados no estatales"],
    casualties: "media",
    summary:
      "Actividad irregular persistente. Ataques contra puestos militares y desplazamiento civil sostenido. Reconfiguración de presencia internacional en curso.",
    timeline: [
      { when: "T-1d", what: "Atentado contra convoy en eje principal." }
    ]
  },
  {
    id: "EV-005",
    type: "armed",
    severity: 4,
    title: "Conflicto prolongado en Península Arábiga",
    location: "Yemen occidental",
    coords: [44.2, 15.4],
    started: "2014-09-21",
    updated: "2026-05-08T09:00Z",
    actors: ["Coalición regional", "Actores no estatales"],
    casualties: "alta",
    summary:
      "Crisis humanitaria de larga duración. Dinámica marítima asociada en Bab el-Mandeb con implicaciones para rutas comerciales globales.",
    timeline: [
      { when: "T-3h", what: "Incidente con buque mercante en estrecho." }
    ]
  },
  {
    id: "EV-006",
    type: "diplo",
    severity: 3,
    title: "Tensión marítima en Mar de China Meridional",
    location: "Spratly · aguas disputadas",
    coords: [114.0, 10.5],
    started: "2024-01-01",
    updated: "2026-05-09T03:20Z",
    actors: ["CN", "PH", "VN", "US", "ASEAN"],
    casualties: "ninguna",
    summary:
      "Maniobras navales y reclamaciones de soberanía solapadas. Patrullas de libertad de navegación recurrentes. Diálogo a través de ASEAN.",
    timeline: [
      { when: "T-5h", what: "Encontronazo entre guardacostas y pesqueros." }
    ]
  },
  {
    id: "EV-007",
    type: "diplo",
    severity: 3,
    title: "Tensión balística en Península Coreana",
    location: "Mar del Japón",
    coords: [129.5, 39.0],
    started: "2024-09-01",
    updated: "2026-05-08T19:55Z",
    actors: ["KP", "KR", "JP", "US"],
    casualties: "ninguna",
    summary:
      "Pruebas balísticas de corto y medio alcance. Coordinación trilateral aliada activada. Canales diplomáticos a nivel de embajadores.",
    timeline: [
      { when: "T-7h", what: "Lanzamiento detectado al este de la península." }
    ]
  },
  {
    id: "EV-008",
    type: "diplo",
    severity: 2,
    title: "Disputa territorial en Cáucaso Sur",
    location: "Corredor disputado",
    coords: [46.5, 40.0],
    started: "2020-09-27",
    updated: "2026-05-06T10:10Z",
    actors: ["AM", "AZ", "RU", "TR", "UE"],
    casualties: "baja",
    summary:
      "Negociación de demarcación fronteriza en curso. Mediación europea con visitas técnicas mensuales.",
    timeline: []
  },
  {
    id: "EV-009",
    type: "diplo",
    severity: 3,
    title: "Crisis migratoria caribeña",
    location: "Hispaniola",
    coords: [-72.3, 18.9],
    started: "2024-06-01",
    updated: "2026-05-08T16:30Z",
    actors: ["HT", "DO", "OEA", "US"],
    casualties: "ninguna",
    summary:
      "Inestabilidad institucional con efecto en flujos migratorios regionales. Misión multinacional de apoyo a la seguridad activa.",
    timeline: []
  },
  {
    id: "EV-010",
    type: "diplo",
    severity: 2,
    title: "Inestabilidad política andina",
    location: "Altiplano",
    coords: [-68.1, -16.5],
    started: "2025-03-01",
    updated: "2026-05-07T18:00Z",
    actors: ["BO", "Vecindad regional"],
    casualties: "ninguna",
    summary: "Movilizaciones internas con impacto en exportaciones de litio.",
    timeline: []
  },
  {
    id: "EV-011",
    type: "diplo",
    severity: 1,
    title: "Cumbre euroatlántica programada",
    location: "Bruselas",
    coords: [4.35, 50.85],
    started: "2026-05-12",
    updated: "2026-05-09T08:00Z",
    actors: ["UE", "OTAN"],
    casualties: "ninguna",
    summary: "Reunión de coordinación sobre defensa común y ayuda a Ucrania.",
    timeline: []
  },
  {
    id: "EV-012",
    type: "econ",
    severity: 2,
    title: "Negociaciones comerciales bilaterales",
    location: "Washington D.C.",
    coords: [-77.0, 38.9],
    started: "2026-04-20",
    updated: "2026-05-09T01:00Z",
    actors: ["US", "CN"],
    casualties: "ninguna",
    summary:
      "Ronda de conversaciones sobre tarifas en sectores estratégicos: semiconductores, vehículos eléctricos y minerales críticos.",
    timeline: []
  },
  {
    id: "EV-013",
    type: "econ",
    severity: 1,
    title: "Foro económico Asia-Pacífico",
    location: "Singapur",
    coords: [103.8, 1.35],
    started: "2026-05-14",
    updated: "2026-05-09T07:00Z",
    actors: ["ASEAN+", "Sector privado"],
    casualties: "ninguna",
    summary: "Encuentro empresarial con énfasis en cadenas de suministro.",
    timeline: []
  },
  {
    id: "EV-014",
    type: "cyber",
    severity: 3,
    title: "Campaña intrusiva en infraestructura crítica",
    location: "Europa Central",
    coords: [14.4, 50.1],
    started: "2026-05-05",
    updated: "2026-05-09T05:42Z",
    actors: ["Atribución pendiente", "CERT regional"],
    casualties: "ninguna",
    summary:
      "Reconocimiento activo en operadores energéticos. Sin impacto operacional reportado. CERT coordinando contención.",
    timeline: [
      { when: "T-1h", what: "Indicador de compromiso compartido vía MISP." }
    ]
  },
  {
    id: "EV-015",
    type: "cyber",
    severity: 2,
    title: "Ataque ransomware a entidades públicas",
    location: "Sudamérica · cono sur",
    coords: [-58.4, -34.6],
    started: "2026-05-07",
    updated: "2026-05-08T22:15Z",
    actors: ["Grupo no atribuido"],
    casualties: "ninguna",
    summary: "Servicios municipales degradados. Restauración en curso.",
    timeline: []
  },
  {
    id: "EV-016",
    type: "intel",
    severity: 2,
    title: "Vigilancia en ruta marítima ártica",
    location: "Mar de Kara",
    coords: [70.0, 76.0],
    started: "2026-04-01",
    updated: "2026-05-08T12:00Z",
    actors: ["Múltiples observadores"],
    casualties: "ninguna",
    summary:
      "Apertura estacional de la ruta del norte. Tráfico mercante creciente y monitoreo de presencia militar.",
    timeline: []
  },
  {
    id: "EV-017",
    type: "intel",
    severity: 1,
    title: "Estación de investigación antártica",
    location: "Mar de Ross",
    coords: [166.7, -77.8],
    started: "2025-11-01",
    updated: "2026-05-07T15:00Z",
    actors: ["Tratado Antártico"],
    casualties: "ninguna",
    summary: "Rotación de personal científico. Sin incidentes.",
    timeline: []
  }
];

/* Conexiones diplomáticas / arcos animados */
window.GEO_LINKS = [
  { from: [-77.0, 38.9],  to: [116.4, 39.9],   type: "diplo" },   // US <-> CN
  { from: [4.35, 50.85],  to: [37.5, 48.5],    type: "diplo" },   // BRX -> UA
  { from: [-77.0, 38.9],  to: [4.35, 50.85],   type: "diplo" },   // US <-> EU
  { from: [129.5, 39.0],  to: [126.9, 37.6],   type: "diplo" },   // KP -> KR
  { from: [114.0, 10.5],  to: [120.9, 14.6],   type: "diplo" },   // SCS -> PH
  { from: [44.2, 15.4],   to: [51.5, 25.3],    type: "diplo" },   // YE -> QA
  { from: [34.5, 31.5],   to: [31.2, 30.0],    type: "diplo" }    // Levante -> EG
];

window.GEO_TYPES = {
  armed: { label: "Conflicto armado", color: "var(--c-armed)" },
  diplo: { label: "Diplomático",      color: "var(--c-diplo)" },
  econ:  { label: "Económico",        color: "var(--c-econ)"  },
  cyber: { label: "Ciber",            color: "var(--c-cyber)" },
  intel: { label: "Inteligencia",     color: "var(--c-intel)" }
};
