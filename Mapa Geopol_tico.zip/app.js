/* =========================================================
   Mapa Geopolítico — Centro de Mando · v0.1
   Renderizado del mapa + interacciones
   ========================================================= */

const TOPO_URL = "https://cdn.jsdelivr.net/npm/world-atlas@2/countries-50m.json";

const state = {
  filters: { armed: true, diplo: true, econ: true, cyber: true, intel: true },
  layers: { graticule: true, connections: true, labels: true, terminator: false },
  severityMin: 1,
  selectedEvent: null,
  hoverCountry: null,
  countries: null,
  events: window.GEO_EVENTS,
  links: window.GEO_LINKS
};

/* ---------- helpers ---------- */
const $  = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const fmt2 = n => String(n).padStart(2, "0");

function fmtCoord(lng, lat) {
  const ns = lat >= 0 ? "N" : "S";
  const ew = lng >= 0 ? "E" : "W";
  return `${Math.abs(lat).toFixed(2)}°${ns}  ${Math.abs(lng).toFixed(2)}°${ew}`;
}

function visibleEvents() {
  return state.events.filter(e =>
    state.filters[e.type] && e.severity >= state.severityMin
  );
}

/* ---------- clock ---------- */
function tickClock() {
  const now = new Date();
  const utc = `${fmt2(now.getUTCHours())}:${fmt2(now.getUTCMinutes())}:${fmt2(now.getUTCSeconds())}`;
  const date = `${now.getUTCFullYear()}-${fmt2(now.getUTCMonth()+1)}-${fmt2(now.getUTCDate())}`;
  $("#clock-utc").textContent = utc + " UTC";
  $("#clock-date").textContent = date;
}
setInterval(tickClock, 1000);
tickClock();

/* =========================================================
   Mapa
   ========================================================= */
const mapEl = $("#map");
const svg = d3.select(mapEl);
const tooltip = $("#country-tip");

const projection = d3.geoNaturalEarth1();
const path = d3.geoPath(projection);

const g = svg.append("g").attr("class", "viewport");
const gOcean    = g.append("g").attr("class", "g-ocean");
const gGratic   = g.append("g").attr("class", "g-graticule");
const gLand     = g.append("g").attr("class", "g-land");
const gBorders  = g.append("g").attr("class", "g-borders");
const gLinks    = g.append("g").attr("class", "g-links");
const gMarkers  = g.append("g").attr("class", "g-markers");
const gLabels   = g.append("g").attr("class", "g-labels");

function fitProjection() {
  const w = mapEl.clientWidth;
  const h = mapEl.clientHeight;
  svg.attr("viewBox", `0 0 ${w} ${h}`).attr("width", w).attr("height", h);
  // Centrar el mapa en el área disponible
  projection
    .scale(Math.min(w / 6.2, h / 3.1))
    .translate([w / 2, h / 2 + 8]);
}

/* Graticule (retícula lat/lng) */
function drawGraticule() {
  gGratic.selectAll("*").remove();
  if (!state.layers.graticule) return;

  const grat = d3.geoGraticule().step([10, 10]);
  const gratMinor = d3.geoGraticule().step([5, 5]);

  gGratic.append("path")
    .datum(gratMinor())
    .attr("d", path)
    .attr("fill", "none")
    .attr("stroke", "rgba(80,140,160,0.04)")
    .attr("stroke-width", 0.5);

  gGratic.append("path")
    .datum(grat())
    .attr("d", path)
    .attr("fill", "none")
    .attr("stroke", "rgba(80,140,160,0.10)")
    .attr("stroke-width", 0.5);

  // Outline (esfera)
  gGratic.append("path")
    .datum({ type: "Sphere" })
    .attr("d", path)
    .attr("fill", "none")
    .attr("stroke", "rgba(120,170,180,0.20)")
    .attr("stroke-width", 0.8);

  // Ecuador y meridiano de Greenwich destacados
  gGratic.append("path")
    .datum({ type: "LineString", coordinates: [[-180, 0], [-90, 0], [0, 0], [90, 0], [180, 0]] })
    .attr("d", path)
    .attr("fill", "none")
    .attr("stroke", "rgba(217,164,65,0.18)")
    .attr("stroke-dasharray", "2 4")
    .attr("stroke-width", 0.6);
}

/* Países */
function drawCountries(topo) {
  const countries = topojson.feature(topo, topo.objects.countries);
  const borders   = topojson.mesh(topo, topo.objects.countries, (a, b) => a !== b);

  gLand.selectAll("path").remove();
  gLand.selectAll("path")
    .data(countries.features)
    .join("path")
    .attr("d", path)
    .attr("class", "country")
    .attr("fill", "var(--land)")
    .attr("stroke", "var(--land-stroke)")
    .attr("stroke-width", 0.4)
    .attr("vector-effect", "non-scaling-stroke")
    .on("mousemove", (ev, d) => onCountryHover(ev, d))
    .on("mouseleave", () => onCountryLeave());

  gBorders.selectAll("path").remove();
  gBorders.append("path")
    .datum(borders)
    .attr("d", path)
    .attr("fill", "none")
    .attr("stroke", "rgba(120,170,180,0.18)")
    .attr("stroke-width", 0.5);
}

/* Eventos (marcadores) */
function drawEvents() {
  const data = visibleEvents();
  const sel = gMarkers.selectAll("g.event-marker").data(data, d => d.id);

  sel.exit().remove();

  const enter = sel.enter().append("g")
    .attr("class", d => `event-marker type-${d.type}`)
    .attr("data-id", d => d.id);

  enter.append("circle").attr("class", "ring2");
  enter.append("circle").attr("class", "ring1");
  enter.append("circle").attr("class", "core");

  const merged = enter.merge(sel);
  merged
    .attr("transform", d => {
      const p = projection(d.coords);
      return p ? `translate(${p[0]},${p[1]})` : null;
    })
    .classed("selected", d => state.selectedEvent && state.selectedEvent.id === d.id);

  merged.select(".core")
    .attr("r", d => 2.6 + d.severity * 0.6)
    .attr("fill", d => `var(--c-${d.type})`)
    .attr("stroke", "var(--bg-0)")
    .attr("stroke-width", 1.2);

  merged.selectAll(".ring1, .ring2")
    .attr("stroke", d => `var(--c-${d.type})`);

  merged
    .on("click", (ev, d) => selectEvent(d))
    .on("mouseenter", function () { d3.select(this).classed("hover", true); })
    .on("mouseleave", function () { d3.select(this).classed("hover", false); });
}

/* Arcos diplomáticos */
function drawLinks() {
  gLinks.selectAll("*").remove();
  if (!state.layers.connections) return;

  const interp = (a, b, t) => [a[0] + (b[0]-a[0])*t, a[1] + (b[1]-a[1])*t];

  state.links.forEach(link => {
    // Geodésica simple usando d3.geoInterpolate para suavidad
    const interpolate = d3.geoInterpolate(link.from, link.to);
    const coords = d3.range(0, 1.0001, 0.02).map(t => interpolate(t));
    const lineGen = d3.line()
      .x(d => projection(d)[0])
      .y(d => projection(d)[1])
      .curve(d3.curveBasis);
    gLinks.append("path")
      .attr("class", "connection-arc")
      .attr("d", lineGen(coords))
      .attr("stroke", `var(--c-${link.type})`)
      .attr("stroke-width", 0.9);
  });
}

/* Hover de país */
function onCountryHover(ev, feature) {
  d3.select(ev.currentTarget).attr("fill", "var(--land-hover)");
  const name = feature.properties.name || "—";
  state.hoverCountry = name;
  // Eventos que tocan ese país (heurística: bbox aproximada)
  const bounds = d3.geoBounds(feature);
  const matches = visibleEvents().filter(e => {
    const [lng, lat] = e.coords;
    return lng >= bounds[0][0] && lng <= bounds[1][0] && lat >= bounds[0][1] && lat <= bounds[1][1];
  });

  tooltip.classList.add("show");
  tooltip.innerHTML = `
    <div class="name">${name}</div>
    <div class="meta">
      <span>OPS · ${matches.length}</span>
      <span>BBOX ${bounds[0][0].toFixed(0)},${bounds[0][1].toFixed(0)} → ${bounds[1][0].toFixed(0)},${bounds[1][1].toFixed(0)}</span>
    </div>
    ${matches.length ? `
      <div class="events">
        ${matches.slice(0,3).map(e => `
          <div class="ev-line">
            <span class="dot" style="background: var(--c-${e.type})"></span>
            <span>${e.title}</span>
          </div>`).join("")}
      </div>` : ""
    }
  `;
  positionTip(ev);

  // Coord readout
  const inv = projection.invert ? projection.invert([ev.offsetX, ev.offsetY]) : null;
  if (inv) $("#coord-live").textContent = fmtCoord(inv[0], inv[1]);
}

function positionTip(ev) {
  const rect = mapEl.getBoundingClientRect();
  const x = ev.clientX - rect.left;
  const y = ev.clientY - rect.top;
  tooltip.style.left = x + "px";
  tooltip.style.top  = y + "px";
}

function onCountryLeave() {
  gLand.selectAll(".country").attr("fill", "var(--land)");
  tooltip.classList.remove("show");
  state.hoverCountry = null;
}

/* Selección de evento */
function selectEvent(ev) {
  state.selectedEvent = ev;
  drawEvents();
  renderDetail();
  renderFeed();
  // tab a detail
  switchRightTab("detail");
}

/* =========================================================
   Sidebar izquierda — filtros
   ========================================================= */
function renderFilters() {
  const counts = {};
  state.events.forEach(e => counts[e.type] = (counts[e.type] || 0) + 1);
  $$(".filter-row").forEach(row => {
    const t = row.dataset.type;
    row.classList.toggle("active", state.filters[t]);
    row.classList.toggle("muted", !state.filters[t]);
    row.querySelector(".count").textContent = `${counts[t] || 0}`.padStart(2, "0");
  });
}

function renderLayers() {
  $$(".toggle-row").forEach(row => {
    const k = row.dataset.layer;
    row.classList.toggle("on", !!state.layers[k]);
  });
}

function renderSeverity() {
  $$(".sev-cell").forEach(cell => {
    const v = +cell.dataset.sev;
    cell.classList.toggle("on", v >= state.severityMin);
  });
}

/* =========================================================
   Right panel — feed + detail
   ========================================================= */
function renderFeed() {
  const list = $("#feed-list");
  const items = visibleEvents()
    .slice()
    .sort((a, b) => b.severity - a.severity || (a.updated < b.updated ? 1 : -1));

  list.innerHTML = items.map(e => `
    <div class="feed-item ${state.selectedEvent && state.selectedEvent.id === e.id ? 'selected' : ''}"
         data-type="${e.type}" data-id="${e.id}">
      <div class="marker"></div>
      <div class="body">
        <div class="meta">
          <span>${e.id}</span>
          <span class="sev">SEV ${e.severity}</span>
          <span>${e.updated.replace('T', ' ').replace('Z', 'Z')}</span>
        </div>
        <div class="title">${e.title}</div>
        <div class="where">${e.location}</div>
      </div>
    </div>
  `).join("");

  $$(".feed-item", list).forEach(el => {
    el.addEventListener("click", () => {
      const ev = state.events.find(x => x.id === el.dataset.id);
      if (ev) selectEvent(ev);
    });
  });

  $("#count-feed").textContent = items.length;
  $("#count-active").textContent = state.events.filter(e => e.type === "armed").length;
}

function renderDetail() {
  const el = $("#detail");
  const e = state.selectedEvent;
  if (!e) {
    el.className = "detail-card";
    el.innerHTML = `<div class="detail-empty">// selecciona un evento del feed o del mapa</div>`;
    return;
  }
  el.className = `detail-card`;
  el.dataset.type = e.type;
  const typeLabel = window.GEO_TYPES[e.type].label.toUpperCase();
  el.innerHTML = `
    <div class="detail-header">
      <div class="ribbon"><span>${typeLabel} · SEV ${e.severity} · ${e.id}</span></div>
      <div class="h-title">${e.title}</div>
      <div class="h-loc">${e.location} · ${fmtCoord(e.coords[0], e.coords[1])}</div>
    </div>
    <div class="detail-grid">
      <div class="detail-cell"><div class="lbl">Inicio</div><div class="val">${e.started}</div></div>
      <div class="detail-cell"><div class="lbl">Última act.</div><div class="val">${e.updated}</div></div>
      <div class="detail-cell"><div class="lbl">Severidad</div><div class="val acc">${"■".repeat(e.severity)}${"□".repeat(5-e.severity)}</div></div>
      <div class="detail-cell"><div class="lbl">Bajas</div><div class="val">${e.casualties}</div></div>
    </div>
    <div class="detail-summary">${e.summary}</div>
    <div class="detail-actors">
      <div class="lbl">Actores</div>
      <div class="actor-tags">${e.actors.map(a => `<span class="actor-tag">${a}</span>`).join("")}</div>
    </div>
    ${e.timeline.length ? `
      <div class="detail-timeline">
        <div class="lbl">Cronología reciente</div>
        ${e.timeline.map(t => `<div class="tl-item"><div class="when">${t.when}</div><div class="what">${t.what}</div></div>`).join("")}
      </div>` : ""
    }
  `;
}

function switchRightTab(which) {
  $$(".right-tab").forEach(t => t.classList.toggle("active", t.dataset.tab === which));
  $$(".right-pane").forEach(p => p.style.display = p.dataset.pane === which ? "block" : "none");
}

/* =========================================================
   Bottom — timeline scrubber
   ========================================================= */
function renderTimeline() {
  const track = $("#tl-track");
  track.innerHTML = "";
  // Marcadores: distribuir eventos en 24h
  const now = Date.now();
  const range = 24 * 3600 * 1000;
  state.events.forEach(e => {
    const t = new Date(e.updated.replace(/Z$/, "Z")).getTime();
    if (isNaN(t)) return;
    const dt = now - t;
    if (dt < 0 || dt > range) return;
    const pct = 100 - (dt / range) * 100;
    const m = document.createElement("div");
    m.className = "tl-marker";
    m.dataset.type = e.type;
    m.style.left = pct + "%";
    track.appendChild(m);
  });
  // Fill: ventana visible (últimas 24h)
  const fill = document.createElement("div");
  fill.className = "tl-fill";
  fill.style.left = "0%";
  fill.style.width = "100%";
  track.prepend(fill);
}

/* =========================================================
   Wiring
   ========================================================= */
function bindUI() {
  $$(".filter-row").forEach(row => {
    row.addEventListener("click", () => {
      const t = row.dataset.type;
      state.filters[t] = !state.filters[t];
      renderFilters();
      drawEvents();
      renderFeed();
      renderTimeline();
    });
  });

  $$(".toggle-row").forEach(row => {
    row.addEventListener("click", () => {
      const k = row.dataset.layer;
      state.layers[k] = !state.layers[k];
      renderLayers();
      if (k === "graticule") drawGraticule();
      if (k === "connections") drawLinks();
    });
  });

  $$(".sev-cell").forEach(cell => {
    cell.addEventListener("click", () => {
      state.severityMin = +cell.dataset.sev;
      renderSeverity();
      drawEvents();
      renderFeed();
    });
  });

  $$(".right-tab").forEach(t => {
    t.addEventListener("click", () => switchRightTab(t.dataset.tab));
  });

  $$(".region-btn").forEach(b => {
    b.addEventListener("click", () => {
      const region = b.dataset.region;
      flyToRegion(region);
    });
  });

  // Mouse coords
  mapEl.addEventListener("mousemove", ev => {
    const rect = mapEl.getBoundingClientRect();
    const inv = projection.invert([ev.clientX - rect.left, ev.clientY - rect.top]);
    if (inv && !isNaN(inv[0])) {
      $("#coord-live").textContent = fmtCoord(inv[0], inv[1]);
    }
  });

  // Resize
  window.addEventListener("resize", () => {
    fitProjection();
    drawGraticule();
    if (state.countries) drawCountries(state.countries);
    drawLinks();
    drawEvents();
  });
}

/* Pseudo "fly to" — zoom suave a una región */
const REGIONS = {
  global:   { center: [0, 10],     scale: 1 },
  europe:   { center: [15, 50],    scale: 3.2 },
  mena:     { center: [35, 28],    scale: 2.6 },
  africa:   { center: [20, 0],     scale: 2.0 },
  asia:     { center: [100, 30],   scale: 2.0 },
  americas: { center: [-80, 10],   scale: 1.8 },
  arctic:   { center: [40, 75],    scale: 2.5 },
};

let currentZoom = 1;
let currentTranslate = [0, 0];
function flyToRegion(key) {
  const r = REGIONS[key] || REGIONS.global;
  const w = mapEl.clientWidth, h = mapEl.clientHeight;
  const target = projection(r.center);
  const tx = w/2 - target[0] * r.scale;
  const ty = h/2 - target[1] * r.scale;
  g.transition().duration(700)
    .attr("transform", `translate(${tx},${ty}) scale(${r.scale})`);
  currentZoom = r.scale;
}

$("#zoom-in")?.addEventListener("click", () => zoomBy(1.4));
$("#zoom-out")?.addEventListener("click", () => zoomBy(1/1.4));
$("#zoom-reset")?.addEventListener("click", () => {
  currentZoom = 1;
  g.transition().duration(500).attr("transform", "translate(0,0) scale(1)");
});

function zoomBy(k) {
  currentZoom = Math.max(0.6, Math.min(8, currentZoom * k));
  const w = mapEl.clientWidth, h = mapEl.clientHeight;
  const tx = (w/2) * (1 - currentZoom);
  const ty = (h/2) * (1 - currentZoom);
  g.transition().duration(300)
    .attr("transform", `translate(${tx},${ty}) scale(${currentZoom})`);
}

/* =========================================================
   Boot
   ========================================================= */
async function boot() {
  fitProjection();
  drawGraticule();

  try {
    const topo = await fetch(TOPO_URL).then(r => r.json());
    state.countries = topo;
    drawCountries(topo);
  } catch (err) {
    console.warn("No se pudo cargar topojson:", err);
  }

  drawLinks();
  drawEvents();

  bindUI();
  renderFilters();
  renderLayers();
  renderSeverity();
  renderFeed();
  renderDetail();
  renderTimeline();
}
boot();
